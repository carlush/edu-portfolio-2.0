﻿using TestingSystem.Controllers;
public class Group
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public int DirectionId { get; set; }
    public int CourseId { get; set; }
    public int ProjectId { get; set; }

    public Direction Direction { get; set; } = null!;
    public Course Course { get; set; } = null!;
    public Project Project { get; set; } = null!;
    public List<Student> Students { get; set; } = new();
    public List<Test> Tests { get; set; } = new();
}
