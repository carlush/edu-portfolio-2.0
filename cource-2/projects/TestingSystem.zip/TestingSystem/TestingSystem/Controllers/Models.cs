namespace TestingSystem.Controllers;

public class User
{
    public int Id { get; set; }
    public string Login { get; set; } = null!;
    public string PasswordHash { get; set; } = null!;
    public string Email { get; set; } = null!;
    public string FirstName { get; set; } = null!;
    public string? MiddleName { get; set; }
    public string LastName { get; set; } = null!;
    public UserRole Role { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public Student? Student { get; set; }
}

public class Student
{
    public int Id { get; set; }
    public string Phone { get; set; } = null!;
    public string VkProfileLink { get; set; } = null!;
    public int UserId { get; set; }

    public User User { get; set; } = null!;
    public List<Group> Groups { get; set; } = new();
    public List<Test> Tests { get; set; } = new();
    public List<Attempt> Attempts { get; set; } = new();
    public List<TestResult> TestResults { get; set; } = new();
}

public class Group
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public int DirectionId { get; set; }
    public int CourseId { get; set; }
    public int ProjectId { get; set; }

    public Direction Direction { get; set; } = null!;
    public Course Course { get; set; } = null!;
    public Project Project { get; set; } = null!;
    public List<Student> Students { get; set; } = new();
    public List<Test> Tests { get; set; } = new();
}

public class Course
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public List<Group> Groups { get; set; } = new();
    public List<Test> Tests { get; set; } = new();
}

public class Project
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public List<Group> Groups { get; set; } = new();
    public List<Test> Tests { get; set; } = new();
}

public class Direction
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public List<Group> Groups { get; set; } = new();
    public List<Test> Tests { get; set; } = new();
}

public class Test
{
    public int Id { get; set; }
    public string Title { get; set; } = null!;
    public string Description { get; set; } = null!;
    public bool IsRepeatable { get; set; }
    public TestType Type { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset PublishedAt { get; set; }
    public DateTimeOffset Deadline { get; set; }
    public int? DurationMinutes { get; set; }
    public bool IsPublic { get; set; }
    public int? PassingScore { get; set; }
    public int? MaxAttempts { get; set; }

    public List<Question> Questions { get; set; } = new();
    public List<Student> Students { get; set; } = new();
    public List<Project> Projects { get; set; } = new();
    public List<Course> Courses { get; set; } = new();
    public List<Group> Groups { get; set; } = new();
    public List<Direction> Directions { get; set; } = new();
}

public class Question
{
    public int Id { get; set; }
    public string Text { get; set; } = null!;
    public int Number { get; set; }
    public string? Description { get; set; }
    public AnswerType AnswerType { get; set; }
    public bool IsScoring { get; set; }
    public int? MaxScore { get; set; }
    public int TestId { get; set; }

    public Test Test { get; set; } = null!;
    public List<UserAttemptAnswer> UserAttemptAnswers { get; set; } = new();
    public List<Answer> Answers { get; set; } = new();
}

public class Answer
{
    public int Id { get; set; }
    public string Text { get; set; } = null!;
    public bool IsCorrect { get; set; }
    public int QuestionId { get; set; }

    public Question Question { get; set; } = null!;
    public List<UserSelectedOption> UserSelectedOptions { get; set; } = new();
}

public class Attempt
{
    public int Id { get; set; }
    public DateTimeOffset StartedAt { get; set; }
    public DateTimeOffset? SubmittedAt { get; set; }
    public int? Score { get; set; }
    public int TestId { get; set; }
    public int StudentId { get; set; }

    public Test Test { get; set; } = null!;
    public Student Student { get; set; } = null!;
    public List<UserAttemptAnswer> UserAttemptAnswers { get; set; } = new();
}

public class UserAttemptAnswer
{
    public int Id { get; set; }
    public bool IsCorrect { get; set; }
    public int ScoreAwarded { get; set; }
    public int AttemptId { get; set; }
    public int QuestionId { get; set; }

    public Attempt Attempt { get; set; } = null!;
    public Question Question { get; set; } = null!;
    public List<UserSelectedOption>? UserSelectedOptions { get; set; }
    public UserTextAnswer? UserTextAnswer { get; set; }
}

public class UserSelectedOption
{
    public int Id { get; set; }
    public int UserAttemptAnswerId { get; set; }
    public int AnswerId { get; set; }

    public UserAttemptAnswer UserAttemptAnswer { get; set; } = null!;
    public Answer Answer { get; set; } = null!;
}

public class UserTextAnswer
{
    public int Id { get; set; }
    public string TextAnswer { get; set; } = null!;
    public int UserAttemptAnswerId { get; set; }

    public UserAttemptAnswer UserAttemptAnswer { get; set; } = null!;
}

public class TestResult
{
    public int Id { get; set; }
    public bool Passed { get; set; }
    public int TestId { get; set; }
    public int AttemptId { get; set; } // лучшая попытка
    public int StudentId { get; set; }

    public Test Test { get; set; } = null!;
    public Attempt Attempt { get; set; } = null!;
    public Student Student { get; set; } = null!;
}
