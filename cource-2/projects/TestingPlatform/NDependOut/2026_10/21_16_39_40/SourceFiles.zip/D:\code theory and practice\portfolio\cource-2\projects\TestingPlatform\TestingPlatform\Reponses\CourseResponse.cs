﻿using TestingPlatform.Responses;

namespace TestingPlatform.Reponses
{
    public class CourseResponse : BaseResponse
    {
    }
}
