﻿namespace TestingPlatform.Reponses
{
    public class ProjectResponse
    {
    }
}
