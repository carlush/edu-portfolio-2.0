﻿namespace TestingPlatform.Reponses
{
    public class DirectionResponse
    {
    }
}
